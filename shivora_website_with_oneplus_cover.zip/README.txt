SHIVORA WEBSITE PACKAGE

Files:
- index.html: the Shivora starter storefront, with the OnePlus Nord CE4 5G cover added.
- images/: the 3 product photos you supplied.

Before publishing:
1. The listed price ₹199 and old price ₹299 are examples. Open Manage > Edit and set your actual selling price.
2. WhatsApp ordering asks for your WhatsApp number the first time and saves it in that browser on that device.
3. This is a static demo store. Product edits are stored in that browser only; it does not have a shared online database, secure admin login, inventory syncing, or integrated UPI checkout.
4. To publish, upload index.html and the images folder together to a static host. For GitHub Pages, index.html must be at the publishing root.
